namespace Interface;

public interface IPoliticaPrazo
{
    DateTime CalcularDataDevolucao(DateTime dataRetirada);
}

public class PoliticaPrazoAluno : IPoliticaPrazo
{
    public DateTime CalcularDataDevolucao(DateTime dataRetirada)
    {
        return dataRetirada.AddDays(7);
    }
}

public class PoliticaPrazoDocente : IPoliticaPrazo
{
    public DateTime CalcularDataDevolucao(DateTime dataRetirada)
    {
        return dataRetirada.AddDays(14);
    }
}
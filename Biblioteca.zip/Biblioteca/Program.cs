﻿using emprestimo;
using Interface;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length < 3)
        {
            Console.WriteLine("Informe três argumentos: [Tipo] [Titulo] [Data]");
            return;
        }

        string tipo = args[0];
        string titulo = args[1];
        string data = args[2];

        try
        {
            IPoliticaPrazo politicaPrazo;

            if (tipo.Equals("Aluno", StringComparison.OrdinalIgnoreCase))
            {
                politicaPrazo = new PoliticaPrazoAluno();
            }
            else if (tipo.Equals("Docente", StringComparison.OrdinalIgnoreCase))
            {
                politicaPrazo = new PoliticaPrazoDocente();
            }
            else
            {
                throw new ArgumentException("Tipo de usuário inválido. Use 'Aluno' ou 'Docente'.");
            }

            var emprestimo = new Emprestimo(titulo, data, politicaPrazo);
            
            Console.WriteLine($"Empréstimo criado com sucesso para: {emprestimo.Titulo}");
            Console.WriteLine($"Retirada: {emprestimo.DataRetirada:dd/MM/yyyy}");
            Console.WriteLine($"Devolução Prevista: {emprestimo.DataDevolucao:dd/MM/yyyy}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
    }
}
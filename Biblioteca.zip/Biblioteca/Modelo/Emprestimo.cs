using Interface;

namespace emprestimo;

public sealed class Emprestimo
{
    public string Titulo { get; private set; }
    public DateTime DataRetirada { get; private set; }
    public DateTime DataDevolucao { get; private set; }

    public Emprestimo(string titulo, string dataStr, IPoliticaPrazo politicaPrazo)
    {
        AlterarTitulo(titulo);
        AlterarData(dataStr);
        
        if (politicaPrazo == null)
            throw new ArgumentNullException(nameof(politicaPrazo));

        // Calcula a data de devolução baseada na política injetada
        DataDevolucao = politicaPrazo.CalcularDataDevolucao(DataRetirada);
    }

    public void AlterarTitulo(string titulo)
    {
        if (string.IsNullOrWhiteSpace(titulo))
            throw new ArgumentException("O título não pode ser vazio.");
        
        Titulo = titulo;
    }

    public void AlterarData(string dataStr)
    {
        if (!DateTime.TryParse(dataStr, out DateTime data))
            throw new ArgumentException("Data inválida. Tente o formato correto.");
        
        DataRetirada = data;
    }
}
namespace Registro
{
    using Interface;

    public class RegistroConsumo
    {
        public int MesReferencia { get; private set; }
        public int MetrosCubicos { get; private set; }
        public double KiloWatts { get; private set; }

        public RegistroConsumo(string data, int metrosCubicos, double kiloWatts)
        {
            AlterarMes(data);
            AlterarMetrosCubicos(metrosCubicos);
            AlterarEnergia(kiloWatts);
        }

        public void AlterarMes(string dataStr)
        {
            if (!DateTime.TryParse(dataStr, out DateTime data))
                throw new ArgumentException("A data digitada está incorreta");
            
            MesReferencia = data.Month;
        }

        public void AlterarMetrosCubicos(int metrosCubicos)
        {
            if (metrosCubicos < 0)
                throw new ArgumentException("A quantidade de metros cúbicos não pode ser menor que 0");
            
            MetrosCubicos = metrosCubicos;
        }

        public void AlterarEnergia(double kiloWatts) // Adicionado o tipo double
        {
            if (kiloWatts < 0)
                throw new ArgumentException("A quantidade de kiloWatts não pode ser menor que 0");
            
            KiloWatts = kiloWatts;
        }

        public void MostrarInformacoes(IFormatadorConsumo formatador)
        {
            string formatada = formatador.Formatar(MesReferencia, MetrosCubicos, KiloWatts);
            Console.WriteLine(formatada);
        }
    }
}
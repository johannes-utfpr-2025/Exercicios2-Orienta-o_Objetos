namespace Interface
{
    public interface IFormatadorConsumo
    {
        string Formatar(int mesReferencia, int metrosCubicos, double kiloWatts);
    }

    public class Resumido : IFormatadorConsumo
    {
        public string Formatar(int mesReferencia, int metrosCubicos, double kiloWatts)
        {
            return $"Mês: {mesReferencia} || Metros Cúbicos: {metrosCubicos} || Kilo Watts: {kiloWatts}";
        }
    }

    public class Detalhado : IFormatadorConsumo
    {
        public string Formatar(int mesReferencia, int metrosCubicos, double kiloWatts)
        {
            return $"================= Registro De Consumo ================\n" +
                   $"Mês: {mesReferencia} \n" +
                   $"Metros Cúbicos: {metrosCubicos} \n" +
                   $"Kilo Watts: {kiloWatts}\n" +
                   $"===========================================";
        }
    }
}
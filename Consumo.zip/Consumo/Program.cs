﻿using System;
using Registro;
using Interface;

class Program
{
    static void Main(string[] args)
    {
        // Precisamos de 4 argumentos: [0] Tipo (Resumido/Detalhado), [1] Data, [2] Metros, [3] Watts
        if (args.Length < 4)
        {
            Console.WriteLine("Informe quatro argumentos: [Tipo] [Data] [MetrosCúbicos] [KiloWatts]");
            return;
        }

        string tipoVisualizacao = args[0];
        string dataStr = args[1];
        
        if (!int.TryParse(args[2], out int metros))
        {
            Console.WriteLine("O valor de metros cúbicos deve ser um número inteiro válido.");
            return;
        }

        if (!double.TryParse(args[3], out double watts))
        {
            Console.WriteLine("O valor de kiloWatts deve ser um número válido.");
            return;
        }

        try
        {
            var leitura = new RegistroConsumo(dataStr, metros, watts);
            
            IFormatadorConsumo formatador;

            if (tipoVisualizacao.Equals("Resumido", StringComparison.OrdinalIgnoreCase))
            {
                formatador = new Resumido();
            }
            else
            {
                formatador = new Detalhado();
            }

            leitura.MostrarInformacoes(formatador);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro: {ex.Message}");
        }
    }
}
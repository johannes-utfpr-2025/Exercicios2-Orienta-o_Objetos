using System;
using System.Linq;

namespace Encapsulamento.Modelo
{
    public class Dispositivo
    {
        public string Identificador { get; private set; }
        public string SistemaOperacional { get; private set; }
        public string Nome { get; private set; }

        public Dispositivo(string identificador, string sistemaoperacional, string nome)
        {
            AlterarIdentificador(identificador);
            AlterarSistemaOperacional(sistemaoperacional);
            AlterarNome(nome);
        }

        public void AlterarNome(string novonome)
        {
            if (string.IsNullOrWhiteSpace(novonome))
                throw new ArgumentException("O nome não pode ser vazio!!!");

            Nome = novonome;
        }

        public void AlterarIdentificador(string identificador)
        {
            if (string.IsNullOrWhiteSpace(identificador))
                throw new ArgumentException("O identificador não pode ser vazio!!!");

            Identificador = identificador;
        }

        public void AlterarSistemaOperacional(string sistemaoperacional)
        {
            if (string.IsNullOrWhiteSpace(sistemaoperacional))
                throw new ArgumentException("O sistema operacional não pode ser vazio!!!");

            SistemaOperacional = sistemaoperacional;
        }

        public override bool Equals(object obj)
        {
            if (obj is Dispositivo outro)
            {
                return Identificador == outro.Identificador;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Identificador != null ? Identificador.GetHashCode() : 0;
        }
    }

    public class ContaUsuario
    {
        public string Email { get; private set; }
        public Dispositivo[] Dispositivos { get; private set; } = Array.Empty<Dispositivo>();

        public ContaUsuario(string email)
        {
            AlterarEmail(email);
        }

        public void AlterarEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("O e-mail não pode ser vazio!!!");

            Email = email;
        }

        public void AlterarDispositivos(Dispositivo[] dispositivos)
        {
            if (dispositivos == null || dispositivos.Length == 0)
            {
                Dispositivos = Array.Empty<Dispositivo>();
                return;
            }

            if (dispositivos.Length > 5)
                throw new ArgumentException("A conta pode ter no máximo 5 dispositivos.");

            if (dispositivos.Select(d => d.Identificador).Distinct().Count() != dispositivos.Length)
            {
                throw new ArgumentException("Membro inserido em duplicidade");
            }

            Dispositivos = (Dispositivo[])dispositivos.Clone();
        }
    }
}
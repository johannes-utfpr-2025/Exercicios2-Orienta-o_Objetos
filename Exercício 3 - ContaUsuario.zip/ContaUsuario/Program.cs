﻿using System;
using Encapsulamento.Modelo;

public class Program
{
    public static void Main()
    {
        Console.WriteLine("=== INICIANDO TESTES DE ENCAPSULAMENTO ===\n");

        // ---------------------------------------------------------
        // TESTE 1: Criação de Dispositivos e Alterações Válidas
        // ---------------------------------------------------------
        ExecutarTeste("1. Criar Dispositivo Válido", () =>
        {
            Dispositivo d1 = new Dispositivo("DEV-01", "Android 13", "Galaxy S23");
            Console.WriteLine($"   Dispositivo criado: {d1.Nome} ({d1.SistemaOperacional}) - ID: {d1.Identificador}");
            
            d1.AlterarNome("Galaxy S23 Ultra");
            Console.WriteLine($"   Nome alterado com sucesso para: {d1.Nome}");
        });

        // ---------------------------------------------------------
        // TESTE 2: Validações de Erro no Dispositivo
        // ---------------------------------------------------------
        ExecutarTesteExcecaoEsperada("2. Criar Dispositivo com Nome Vazio", () =>
        {
            new Dispositivo("DEV-02", "iOS 17", "");
        });

        ExecutarTesteExcecaoEsperada("3. Alterar Identificador para Vazio", () =>
        {
            Dispositivo d = new Dispositivo("DEV-03", "Windows 11", "Dell XPS");
            d.AlterarIdentificador("   ");
        });

        // ---------------------------------------------------------
        // TESTE 3: Criação de Conta de Usuário e Associação Válida
        // ---------------------------------------------------------
        ExecutarTeste("4. Criar ContaUsuario e Associar Dispositivos", () =>
        {
            ContaUsuario conta = new ContaUsuario("usuario@empresa.com");
            Console.WriteLine($"   Conta criada para: {conta.Email}");

            Dispositivo[] listaDispositivos = new Dispositivo[]
            {
                new Dispositivo("DEV-101", "Android", "Smartphone 1"),
                new Dispositivo("DEV-102", "iOS", "iPhone 14"),
                new Dispositivo("DEV-103", "Windows", "Notebook Work")
            };

            conta.AlterarDispositivos(listaDispositivos);
            Console.WriteLine($"   Total de dispositivos associados: {conta.Dispositivos.Length}");
        });

        // ---------------------------------------------------------
        // TESTE 4: Exceção de E-mail Vazio na ContaUsuario
        // ---------------------------------------------------------
        ExecutarTesteExcecaoEsperada("5. Alterar E-mail da Conta para Vazio", () =>
        {
            ContaUsuario conta = new ContaUsuario("teste@empresa.com");
            conta.AlterarEmail(null);
        });

        // ---------------------------------------------------------
        // TESTE 5: Exceção de Limite Máximo (> 5 Dispositivos)
        // ---------------------------------------------------------
        ExecutarTesteExcecaoEsperada("6. Tentar Adicionar mais de 5 Dispositivos", () =>
        {
            ContaUsuario conta = new ContaUsuario("usuario@empresa.com");
            Dispositivo[] muitosDispositivos = new Dispositivo[]
            {
                new Dispositivo("D1", "iOS", "Disp 1"),
                new Dispositivo("D2", "iOS", "Disp 2"),
                new Dispositivo("D3", "iOS", "Disp 3"),
                new Dispositivo("D4", "iOS", "Disp 4"),
                new Dispositivo("D5", "iOS", "Disp 5"),
                new Dispositivo("D6", "iOS", "Disp 6") // 6º dispositivo
            };

            conta.AlterarDispositivos(muitosDispositivos);
        });

        // ---------------------------------------------------------
        // TESTE 6: Exceção de Dispositivo Duplicado
        // ---------------------------------------------------------
        ExecutarTesteExcecaoEsperada("7. Tentar Adicionar Dispositivos Duplicados", () =>
        {
            ContaUsuario conta = new ContaUsuario("usuario@empresa.com");
            Dispositivo[] dispositivosDuplicados = new Dispositivo[]
            {
                new Dispositivo("DEV-MESMO-ID", "Android", "Celular A"),
                new Dispositivo("DEV-MESMO-ID", "Android", "Celular B (Mesmo ID)")
            };

            conta.AlterarDispositivos(dispositivosDuplicados);
        });

        Console.WriteLine("\n=== TODOS OS TESTES FORAM EXECUTADOS ===");
    }

    // Auxiliar para executar testes normais
    private static void ExecutarTeste(string nomeTeste, Action acao)
    {
        Console.WriteLine($"\n[TESTE] {nomeTeste}");
        try
        {
            acao();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("--> RESULTADO: SUCESSO");
            Console.ResetColor();
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"--> RESULTADO: FALHA INESPERADA - {ex.Message}");
            Console.ResetColor();
        }
    }

    // Auxiliar para verificar se as exceções de validação estão funcionando
    private static void ExecutarTesteExcecaoEsperada(string nomeTeste, Action acao)
    {
        Console.WriteLine($"\n[TESTE EXCEÇÃO ESPERADA] {nomeTeste}");
        try
        {
            acao();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("--> RESULTADO: FALHA (Exceção esperada não foi lançada)");
            Console.ResetColor();
        }
        catch (ArgumentException ex)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"--> RESULTADO: SUCESSO (Exceção capturada: \"{ex.Message}\")");
            Console.ResetColor();
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"--> RESULTADO: ATENÇÃO (Exceção de outro tipo lançada: {ex.GetType().Name} - {ex.Message})");
            Console.ResetColor();
        }
    }
}
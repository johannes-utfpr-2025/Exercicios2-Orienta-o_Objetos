﻿using System;
using Encapsulamento.Modelo;

namespace Encapsulamento
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=====================================");
            Console.WriteLine("       TESTES DE SUCESSO (HAPPY PATH)");
            Console.WriteLine("=====================================");

            try
            {
                // Teste 1: Criação e alteração de Livro
                Livro livro1 = new Livro("O Senhor dos Anéis", 1001);
                Console.WriteLine($"[OK] Livro criado: \"{livro1.Titulo}\" (ISBN: {livro1.ISBN})");

                livro1.AlterarTitulo("O Hobbit");
                livro1.AlterarISBN(1002);
                Console.WriteLine($"[OK] Livro alterado: \"{livro1.Titulo}\" (ISBN: {livro1.ISBN})");

                // Teste 2: Criação de Leitor
                Leitor leitor1 = new Leitor("Carlos Silva");
                Console.WriteLine($"[OK] Leitor criado: {leitor1.Nome}");

                // Teste 3: Empréstimo válido de livros
                int[] livrosParaEmprestar = { 1001, 1002, 1003 };
                leitor1.RegistrarEmprestimo(livrosParaEmprestar);
                Console.WriteLine($"[OK] Empréstimo realizado para {leitor1.Nome}. Qtd de livros: {leitor1.Livros.Length}");
                Console.WriteLine($"     ISBNs emprestados: {string.Join(", ", leitor1.Livros)}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FALHA INESPERADA] {ex.Message}");
            }

            Console.WriteLine("\n=====================================");
            Console.WriteLine("  TESTES DE VALIDAÇÃO (EXCEÇÕES)");
            Console.WriteLine("=====================================");

            // Teste 4: Título de livro vazio
            ExecutarTesteExcecao("Criar livro com título vazio", () => new Livro("", 1001));

            // Teste 5: ISBN igual ou menor que zero
            ExecutarTesteExcecao("Criar livro com ISBN inválido (<= 0)", () => new Livro("Dom Casmurro", 0));

            // Teste 6: Nome de leitor vazio
            ExecutarTesteExcecao("Criar leitor com nome em branco", () => new Leitor("   "));

            // Teste 7: Empréstimo com ISBNs duplicados (não consecutivos)
            ExecutarTesteExcecao("Empréstimo com ISBNs duplicados [101, 202, 101]", () =>
            {
                Leitor leitor = new Leitor("Maria Souza");
                leitor.RegistrarEmprestimo(new int[] { 101, 202, 101 });
            });

            Console.WriteLine("\nTestes concluídos!");
        }

        /// <summary>
        /// Método auxiliar para validar se uma determinada ação lança ArgumentException como esperado.
        /// </summary>
        static void ExecutarTesteExcecao(string nomeTeste, Action acao)
        {
            try
            {
                acao();
                Console.WriteLine($"[ERRO DE TESTE] {nomeTeste}: Deveria ter falhado, mas passou.");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"[SUCESSO NO TESTE] {nomeTeste} -> Lançou exceção esperada: \"{ex.Message}\"");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERRO DE TESTE] {nomeTeste} -> Exceção inesperada: {ex.GetType().Name} - {ex.Message}");
            }
        }
    }
}
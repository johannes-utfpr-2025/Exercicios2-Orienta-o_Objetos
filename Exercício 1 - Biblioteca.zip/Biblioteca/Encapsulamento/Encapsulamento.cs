using System;
using System.Linq;

namespace Encapsulamento.Modelo
{
    public class Livro
    {
        public string Titulo { get; private set; } = string.Empty;
        public int ISBN { get; private set; }

        // Construtor
        public Livro(string titulo, int isbn)
        {
            AlterarTitulo(titulo);
            AlterarISBN(isbn);
        }

        public void AlterarTitulo(string? novoTitulo)
        {
            if (string.IsNullOrWhiteSpace(novoTitulo))
                throw new ArgumentException("O título não pode ser vazio ou nulo!");

            Titulo = novoTitulo;
        }

        public void AlterarISBN(int? isbn)
        {
            if (!isbn.HasValue || isbn.Value <= 0)
                throw new ArgumentException("O ISBN não pode ser nulo, zero ou negativo!");

            ISBN = isbn.Value;
        }
    }

    public class Leitor
    {
        public string Nome { get; private set; } = string.Empty;
        public int[] Livros { get; private set; } = Array.Empty<int>();

        // Construtor
        public Leitor(string nome)
        {
            AlterarNome(nome);
        }

        public void AlterarNome(string? novoNome)
        {
            if (string.IsNullOrWhiteSpace(novoNome))
                throw new ArgumentException("O nome não pode ser vazio ou nulo!");

            Nome = novoNome;
        }

        public void RegistrarEmprestimo(int[]? livros)
        {
            if (livros == null || livros.Length == 0)
            {
                Livros = Array.Empty<int>();
                return;
            }

            // Verifica se existem livros duplicados no array (mesmo que não estejam lado a lado)
            if (livros.Length != livros.Distinct().Count())
            {
                throw new ArgumentException("Não é permitido emprestar livros duplicados para o mesmo leitor!");
            }

            // Clona o array para proteger o encapsulamento interno
            Livros = (int[])livros.Clone();
        }
    }
}
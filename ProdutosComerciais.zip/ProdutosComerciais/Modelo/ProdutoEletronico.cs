namespace ProdutoEletronico;

public class Eletronico : Produto
{
    public string Marca {get; private set;}
    public int MesesGarantia{get; private set;}

    public Eletronico(int codigo, string descricao, decimal precobase, string marca, int mesesgarantia) : base(codigo, descricao, precobase)
    {
        AlterarMarca(marca);
        AlterarMesesGarantia(mesesgarantia);
    }

    public void AlterarMarca(string marca)
    {
        if(string.IsNullOrWhiteSpace(marca))
            throw new ArgumentExcpetion("A marca não pode ser vazia");
        
        Marca = marca;
    }

    public void AlterarMesesGarantia(int mesesgarantia)
    {
        if(mesesgarantia < 0)
            throw new ArgumentException("A quantidade não pode ser menor que 0");
        
        MesesGarantia = mesesgarantia;
    }

    public void ExibirDados()
    {
        Console.WriteLine($"Codigo: {Codigo} || Descricao: {Descricao} || Preco : {Preco} || Marca: {Marca} || Meses de Garantia: {MesesGarantia}");
    }
}
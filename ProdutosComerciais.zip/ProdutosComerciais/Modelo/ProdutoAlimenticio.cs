namespace ProdutoAlimenticio;

public class Alimenticio : Produto
{
    public DateTime DataValidade{get; private set;}
    public bool Vencido{get; private set;}
    public bool ProdutoRefrigerado{get; private set;}

    public Alimenticio(int codigo, string descricao, decimal preco, DateTime datavalidade, bool refrigerado) : base(codigo, descricao, preco)
    {
        AlterarDataValidade(datavalidade);
        Vencido = ChecarVencimento();
        ProdutoRefrigerado = refrigerado;
    }

    public void AlterarDataValidade(DateTime datavalidade)
    {
        if(!DateTime.TryParse(datavalidade, out DateTime data)
            throw new ArgumentException("A data informada é invalida");
        
        DataValidade = data;
    }

    public bool ChecarVencimento()
    {
        if(DataValidade > DateTime.Now())
            return true;
        else
            return false;
    }

}
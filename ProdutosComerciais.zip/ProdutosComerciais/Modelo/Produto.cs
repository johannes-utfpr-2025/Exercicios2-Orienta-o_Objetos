namespace Prod;

public class Produto
{
    public int Codigo {get; private set;}
    public string Descricao{get; private set;}
    public decimal Preco{get; private set;}

    public Produto(int codigo, string descricao, decimal preco)
    {
        AlterarCodigo(codigo);
        AlterarDescricao(descricao);
        AlterarPreco(preco);
    }

    public void AlterarCodigo(int codigo)
    {
        if(codigo < 0)
            throw new ArgumentException("O codigo não pode ser menor que 0");
        
        Codigo = codigo;
    }

    public void AlterarDescricao(string descricao)
    {
        if(string.IsNullOrWhiteSpace(descricao))
            throw new ArgumentExcpetion("A descrição não pode ser vazia");
        
        Descricao = descricao;
    }

    public void AlterarPreco(decimal preco)
    {
        if(preco < 0)
            throw new ArgumentException("O preco não pode ser menor que 0");
        
        Preco = preco;
    }
}
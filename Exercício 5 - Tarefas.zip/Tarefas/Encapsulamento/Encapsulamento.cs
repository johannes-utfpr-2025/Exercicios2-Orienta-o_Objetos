using System;
using System.Linq;

namespace Encapsulamento.Modelo
{
    public class Tarefa
    {
        public string Titulo { get; private set; } = string.Empty;
        public int Codigo { get; private set; }
        public bool Situacao { get; private set; }

        public Tarefa(string titulo, int codigo, bool situacao)
        {
            AlterarTitulo(titulo);
            AlterarCodigo(codigo);
            AlterarSituacao(situacao);
        }

        public void AlterarTitulo(string titulo)
        {
            if (string.IsNullOrWhiteSpace(titulo))
                throw new ArgumentException("O titulo não pode ser vazio!!!");

            Titulo = titulo;
        }

        public void AlterarCodigo(int codigo)
        {
            if (codigo <= 0)
                throw new ArgumentException("O código não pode ser igual ou menor que 0!!!");

            Codigo = codigo;
        }

        // Sobrecarga para aceitar bool diretamente
        public void AlterarSituacao(bool situacao)
        {
            Situacao = situacao;
        }

        // Sobrecarga para aceitar texto ("sim", "nao", "s", "n")
        public void AlterarSituacao(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                throw new ArgumentException("Responda com sim ou nao !!!");

            string textoTratado = texto.Trim().ToLower();

            if (textoTratado == "s" || textoTratado == "sim")
            {
                Situacao = true;
            }
            else if (textoTratado == "n" || textoTratado == "nao" || textoTratado == "não")
            {
                Situacao = false;
            }
            else
            {
                throw new ArgumentException("Responda com sim ou nao !!!");
            }
        }

        // Método utilitário para retornar o status em formato de texto
        public string ObterStatusTexto()
        {
            return Situacao ? "concluída" : "em andamento";
        }

        // Permite que o Distinct() identifique duplicidades pelo Código da tarefa
        public override bool Equals(object? obj)
        {
            if (obj is Tarefa outra)
            {
                return Codigo == outra.Codigo;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Codigo);
        }
    }

    public class Projeto
    {
        public string Nome { get; private set; } = string.Empty;
        public Tarefa[] Tarefas { get; private set; } = Array.Empty<Tarefa>();

        public Projeto(string nome, Tarefa[]? tarefas = null)
        {
            AlterarNome(nome);
            if (tarefas != null)
            {
                AlterarTarefas(tarefas);
            }
        }

        public void AlterarNome(string? novoNome)
        {
            if (string.IsNullOrWhiteSpace(novoNome))
                throw new ArgumentException("O nome não pode ser vazio!!!");

            Nome = novoNome;
        }

        public void AlterarTarefas(Tarefa[] tarefas)
        {
            if (tarefas == null || tarefas.Length == 0)
            {
                Tarefas = Array.Empty<Tarefa>();
                return;
            }

            if (tarefas.Length != tarefas.Distinct().Count())
            {
                throw new ArgumentException("Tarefa inserida em duplicidade");
            }

            Tarefas = (Tarefa[])tarefas.Clone();
        }
    }
}
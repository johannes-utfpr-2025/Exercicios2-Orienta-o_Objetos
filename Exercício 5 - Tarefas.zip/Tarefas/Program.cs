﻿using System;
using Encapsulamento.Modelo;

namespace Encapsulamento
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==================================================");
            Console.WriteLine("          INICIANDO BATERIA DE TESTES             ");
            Console.WriteLine("==================================================\n");

            // ----------------------------------------------------
            // TESTE: IMPRESSÃO DA SITUAÇÃO ("concluída" / "em andamento")
            // ----------------------------------------------------
            Console.WriteLine("--- [TESTE: Formatação do Status da Tarefa] ---");

            var t1 = new Tarefa("Criar modelagem do banco de dados", 101, true);
            var t2 = new Tarefa("Desenvolver API REST", 102, false);
            var t3 = new Tarefa("Escrever documentação", 103, false);

            ImprimirTarefa(t1); // Imprime: concluída
            ImprimirTarefa(t2); // Imprime: em andamento

            // Alterando a situação da tarefa 3 através de texto
            Console.WriteLine("\nAlterando situação da Tarefa #103 via texto ('sim')...");
            t3.AlterarSituacao("sim");
            ImprimirTarefa(t3); // Imprime: concluída

            // ----------------------------------------------------
            // TESTE: CRIAÇÃO DE PROJETO E LISTAGEM
            // ----------------------------------------------------
            Console.WriteLine("\n--- [TESTE: Projeto e Associação de Tarefas] ---");

            ExecutarTeste("Criar Projeto e Imprimir Status de Todas as Tarefas", () =>
            {
                var tarefas = new Tarefa[]
                {
                    new Tarefa("Configurar ambiente de dev", 1, true),
                    new Tarefa("Implementar tela de Login", 2, false),
                    new Tarefa("Criar testes unitários", 3, false)
                };

                var projeto = new Projeto("Sistema Web", tarefas);

                Console.WriteLine($"\nProjeto: {projeto.Nome}");
                Console.WriteLine("Tarefas do Projeto:");
                foreach (var t in projeto.Tarefas)
                {
                    ImprimirTarefa(t);
                }

                Assert(projeto.Tarefas.Length == 3, "A quantidade de tarefas do projeto está incorreta.");
            });

            // ----------------------------------------------------
            // TESTES DE EXCEÇÃO E REGRAS DE NEGÓCIO
            // ----------------------------------------------------
            Console.WriteLine("\n--- [TESTES: Validação de Exceções] ---");

            ExecutarTesteExcecao<ArgumentException>("Criar Tarefa com Título Vazio", () =>
            {
                new Tarefa("   ", 1, true);
            });

            ExecutarTesteExcecao<ArgumentException>("Criar Tarefa com Código Menor ou Igual a Zero", () =>
            {
                new Tarefa("Ajustar layout", -10, false);
            });

            ExecutarTesteExcecao<ArgumentException>("Alterar Situação com Texto Inválido", () =>
            {
                var t = new Tarefa("Ajustar bugs", 5, false);
                t.AlterarSituacao("talvez");
            });

            ExecutarTesteExcecao<ArgumentException>("Criar Projeto com Nome Vazio", () =>
            {
                new Projeto("   ");
            });

            ExecutarTesteExcecao<ArgumentException>("Projeto com Tarefas Duplicadas", () =>
            {
                var tA = new Tarefa("Tarefa A", 1, true);
                var tADuplicada = new Tarefa("Tarefa A com mesmo Código", 1, false);

                new Projeto("Projeto Inválido", new[] { tA, tADuplicada });
            });

            Console.WriteLine("\n==================================================");
            Console.WriteLine("          TODOS OS TESTES CONCLUÍDOS!             ");
            Console.WriteLine("==================================================");
        }

        /// <summary>
        /// Imprime a tarefa convertendo Situacao == true para "concluída" e false para "em andamento"
        /// </summary>
        static void ImprimirTarefa(Tarefa tarefa)
        {
            string statusTexto = tarefa.Situacao ? "concluída" : "em andamento";
            Console.WriteLine($" -> [Código {tarefa.Codigo}] \"{tarefa.Titulo}\" | Situação: {statusTexto}");
        }

        #region Helpers de Suporte aos Testes
        static void ExecutarTeste(string nomeTeste, Action acao)
        {
            try
            {
                acao();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"[PASSOU] - {nomeTeste}");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[FALHOU] - {nomeTeste}: {ex.Message}");
            }
            finally
            {
                Console.ResetColor();
            }
        }

        static void ExecutarTesteExcecao<TExcecao>(string nomeTeste, Action acao) where TExcecao : Exception
        {
            try
            {
                acao();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[FALHOU] - {nomeTeste}: Nenhuma exceção foi lançada (esperava {typeof(TExcecao).Name}).");
            }
            catch (TExcecao)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"[PASSOU] - {nomeTeste} (Exceção capturada com sucesso)");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[FALHOU] - {nomeTeste}: Lançou {ex.GetType().Name} em vez de {typeof(TExcecao).Name}. Mensagem: {ex.Message}");
            }
            finally
            {
                Console.ResetColor();
            }
        }

        static void Assert(bool condicao, string mensagemErro)
        {
            if (!condicao)
                throw new Exception(mensagemErro);
        }
        #endregion
    }
}
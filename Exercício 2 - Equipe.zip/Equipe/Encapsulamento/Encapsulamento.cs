using System;
using System.Linq;

namespace Encapsulamento.Modelo
{
    public class Profissional
    {
        public string Nome { get; private set; }
        public string Email { get; private set; }
        public string Especialidade { get; private set; }

        public Profissional(string nome, string email, string especialidade)
        {
            AlterarNome(nome);
            AlterarEmail(email); 
            AlterarEspecialidade(especialidade);
        }

        public void AlterarNome(string novonome)
        {
            if (string.IsNullOrWhiteSpace(novonome))
                throw new ArgumentException("O nome não pode ser vazio!!!");

            Nome = novonome;
        }

        public void AlterarEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ArgumentException("O e-mail não pode ser vazio!!!"); // Correção na mensagem

            Email = email;
        }

        public void AlterarEspecialidade(string especialidade)
        {
            if (string.IsNullOrWhiteSpace(especialidade))
                throw new ArgumentException("A especialidade não pode ser vazia!!!"); // Correção na mensagem

            Especialidade = especialidade;
        }
    }

    public class Equipe
    {
        public string Nome { get; private set; }
        public string Lider { get; private set; }
        public Profissional[] Membros { get; private set; } = Array.Empty<Profissional>(); 

        public Equipe(string nome, string lider)
        {
            AlterarNome(nome);
            AlterarLider(lider); 
        }

        public void AlterarNome(string novonome)
        {
            if (string.IsNullOrWhiteSpace(novonome))
                throw new ArgumentException("O nome da equipe não pode ser vazio!!!");

            Nome = novonome;
        }

        public void AlterarLider(string lider)
        {
            if (string.IsNullOrWhiteSpace(lider))
                throw new ArgumentException("O líder não pode ser vazio!!!"); // Correção na mensagem

            Lider = lider;
        }

        public void AlterarMembros(Profissional[] membros)
        {
            if (membros == null || membros.Length == 0)
            {
                Membros = Array.Empty<Profissional>();
                return;
            }

            if (membros.Length > 6)
                throw new ArgumentException("A equipe pode ter no máximo 6 membros.");

            if (membros.Any(m => m == null))
                throw new ArgumentException("A lista de membros contém elementos nulos.");

            if (membros.Length != membros.Distinct().Count())
            {
                throw new ArgumentException("Membro inserido em duplicidade");
            }

            Membros = (Profissional[])membros.Clone();
        }
    }
}
﻿using System;
using Encapsulamento.Modelo;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("========================================");
        Console.WriteLine("    TESTES DE UNIDADE / EXECUÇÃO        ");
        Console.WriteLine("========================================\n");

        // 1. TESTE DE SUCESSO - Criação válida de Profissionais e Equipe
        try
        {
            Console.WriteLine("[TESTE 1] Criando profissionais e equipe válida...");
            Profissional p1 = new Profissional("Ana Silva", "ana@empresa.com", "Desenvolvedora C#");
            Profissional p2 = new Profissional("Carlos Souza", "carlos@empresa.com", "DevOps");
            Profissional p3 = new Profissional("Mariana Lima", "mariana@empresa.com", "UX Designer");

            Equipe equipe = new Equipe("Time Alpha", "Ana Silva");
            equipe.AlterarMembros(new Profissional[] { p1, p2, p3 });

            Console.WriteLine($"✔ Equipe '{equipe.Nome}' criada com sucesso com {equipe.Membros.Length} membros.\n");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ FALHA no Teste 1: {ex.Message}\n");
        }

        // 2. TESTE DE EXCEÇÃO - Instanciação de Profissional com e-mail inválido
        try
        {
            Console.WriteLine("[TESTE 2] Tentando criar profissional com e-mail em branco...");
            Profissional pInvalido = new Profissional("João", "", "QA");
            Console.WriteLine("❌ FALHA: Deveria ter gerado uma exceção.");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"✔ SUCESSO (Exceção esperada capturada): {ex.Message}\n");
        }

        // 3. TESTE DE EXCEÇÃO - Equipe excedendo limite de 6 membros
        try
        {
            Console.WriteLine("[TESTE 3] Tentando adicionar mais de 6 membros...");
            Equipe equipeGrande = new Equipe("Time Beta", "Líder Beta");
            Profissional[] timeExcedente = new Profissional[7];

            for (int i = 0; i < 7; i++)
            {
                timeExcedente[i] = new Profissional($"Dev {i + 1}", $"dev{i + 1}@empresa.com", "Backend");
            }

            equipeGrande.AlterarMembros(timeExcedente);
            Console.WriteLine("❌ FALHA: Deveria ter gerado uma exceção.");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"✔ SUCESSO (Exceção esperada capturada): {ex.Message}\n");
        }

        // 4. TESTE DE EXCEÇÃO - Adicionar membro duplicado
        try
        {
            Console.WriteLine("[TESTE 4] Tentando adicionar membros duplicados...");
            Equipe equipeDuplicada = new Equipe("Time Gama", "Líder Gama");
            Profissional pDuplicado = new Profissional("Lucas", "lucas@empresa.com", "Frontend");

            equipeDuplicada.AlterarMembros(new Profissional[] { pDuplicado, pDuplicado });
            Console.WriteLine("❌ FALHA: Deveria ter gerado uma exceção.");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"✔ SUCESSO (Exceção esperada capturada): {ex.Message}\n");
        }

        Console.WriteLine("========================================");
        Console.WriteLine("      TODOS OS TESTES CONCLUÍDOS       ");
        Console.WriteLine("========================================");
    }
}
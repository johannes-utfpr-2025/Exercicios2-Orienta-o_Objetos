namespace Encap.Modelo;

public class Encapsula
{
    public string Nome {get; private set;}
    public bool Inscricao{get; private set;}

    //Construtor
    public Encapsula(string nome, bool situacao)
    {
        AlterarNome(nome);
        situacao = true;
    }

    public void AlterarNome(string ? novonome)
    {
        if(string.IsNullOrWhiteSpace(novonome))
            throw new ArgumentException("O nome não pode ser vazio!!!");

        Nome = novonome;
    }

    public void Cancelar(string? texto)
    {
        if (texto == "s" || texto == "sim")
        {
            Inscricao = false;
        }
        else if (texto == "n" || texto == "nao" || texto == "não")
        {
            Inscricao = true;
        }
        else
        {
            throw new ArgumentException("Responda com sim ou nao !!!");
        }
    }

    public void Reativar(string? texto)
    {
        if (texto == "s" || texto == "sim")
        {
            Inscricao = true;
        }
        else if (texto == "n" || texto == "nao" || texto == "não")
        {
            Inscricao = false;
        }
        else
        {
            throw new ArgumentException("Responda com sim ou nao !!!");
        }
    }
}
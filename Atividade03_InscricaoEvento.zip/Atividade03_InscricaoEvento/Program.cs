﻿using Encap.Modelo;

var aluno = new Encapsula("João Silva", true);
Console.WriteLine($"[CRIADO] Aluno: {aluno.Nome} | Inscrição Ativa: {aluno.Inscricao}");

// Cancelar inscrição
aluno.Cancelar("sim");
Console.WriteLine($"[CANCELADO] Inscrição Ativa: {aluno.Inscricao}");

// Reativar inscrição
aluno.Reativar("s");
Console.WriteLine($"[REATIVADO] Inscrição Ativa: {aluno.Inscricao}\n");

//Invalidos
//Console.WriteLine("Tentando criar com nome vazio...");
//var alunoInvalido = new Encapsula("   ");

//Console.WriteLine("Tentando cancelar com resposta inválida...");
//var aluno = new Encapsula("Maria Souza");
//aluno.Cancelar("talvez");
namespace Encap.Modelo;

public class Produto
{
    public string Descricao {get; private set;}
    public decimal Preco{get; private set;}
    public int Quantidade{get; private set;}

    //Construtor
    public Produto(string descricao, decimal valor, int quantidade)
    {
        AlterarDescricao(descricao);
        AlterarPreco(valor);
        AumentarQuantidade(quantidade);
    }

    public void AlterarDescricao(string ? novadescricao)
    {
        if(string.IsNullOrWhiteSpace(novadescricao))
            throw new ArgumentException("Descricao não pode ser vazia!!!");

        Descricao = novadescricao;
    }

    public void AlterarPreco(decimal? novovalor)
    {
        if(novovalor <= 0)
            throw new ArgumentException("O valor não pode ser igual ou menor que 0!!!");

        Preco = (decimal)novovalor;
    }

    public void AumentarQuantidade(int? novaquantidade)
    {
        if(novaquantidade <= 0)
            throw new ArgumentException("O novo limite não pode ser igual ou menor que 0!!!");
        Quantidade += (int)novaquantidade;
                CalcularValorEstoque();
    }

    public void DiminuirQuantidade(int? novaquantidade)
    {
        if(novaquantidade > Quantidade)
            throw new ArgumentException("O novo estoque não pode ser menor que o disponível!!!");
        Quantidade -= (int)novaquantidade;
        CalcularValorEstoque();
    }

    public decimal CalcularValorEstoque()
    {
        return Preco * Quantidade;
    }
}
﻿using Encap.Modelo;

var produto = new Produto("Teclado Mecânico", 150.00m, 10);
Console.WriteLine($"[CRIADO] {produto.Descricao} | Valor Unitário: R${produto.Preco} | Estoque: {produto.Quantidade}");
Console.WriteLine($"Total em Estoque: R${produto.CalcularValorEstoque()}\n");

// Aumentar estoque
produto.AumentarQuantidade(5);
Console.WriteLine($"[ESTOQUE AUMENTADO] Novo estoque: {produto.Quantidade} | Total: R${produto.CalcularValorEstoque()}");

// Diminuir estoque
produto.DiminuirQuantidade(3);
Console.WriteLine($"[ESTOQUE REDUZIDO] Novo estoque: {produto.Quantidade} | Total: R${produto.CalcularValorEstoque()}\n");

//Invalido
//Console.WriteLine("Tentando retirar mais do que o estoque disponível...");
//var produto = new Produto("Mouse Gamer", 80.00m, 2);
//produto.DiminuirQuantidade(5); // Deve disparar erro
//Console.WriteLine("Tentando criar produto com preço negativo...");
//var produtoInvalido = new Produto("Monitor", -200.00m, 5);
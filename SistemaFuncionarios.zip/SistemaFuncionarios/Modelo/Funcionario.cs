namespace Func;

public class Funcionario
{
    public string Nome{get; private set;}
    public int Matricula{get; private set;}
    public decimal Salario{get; private set;}

    public Funcionario(string nome, int matricula, decimal salario)
    {
        AlterarNome(nome);
        AlterarMatricula(matricula);
        AlterarSalario(salario);
    }

    public void AlterarNome(string nome)
    {
        if(string.IsNullOrWhiteSpace(nome))
        {
            throw new ArgumentException("O nome cadastrado deve ter caracteres");
        }

        Nome = nome;
    }

    public void AlterarMatricula(int matricula)
    {
        if(matricula < 0)
            throw new ArgumentException("A matricula não pode ser menor que 0");

        Matricula = matricula;
    }

    public void AlterarSalario(decimal salario)
    {
        if(salario < 0)
            throw new ArgumentException("O salário deve ser maior que 0");
        
        Salario = salario;
    }

    public void ExibirDados()
    {
        Console.WriteLine($"Nome: {Nome} || Matricula: {Matricula} || Salario: {Salario}");
    }

}
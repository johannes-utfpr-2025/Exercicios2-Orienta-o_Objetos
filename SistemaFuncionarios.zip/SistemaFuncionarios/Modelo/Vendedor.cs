using Func;
namespace FuncionarioVendedor;

public class Vendedor : Funcionario
{
    public double Percentual;
    public int TotalVendas;

    public Vendedor(string nome, int matricula, decimal salario, double percentual, int totalvendas) : base(nome,matricula,salario)
    {
        AlterarPercentual(percentual);
        AlterarTotal(totalvendas);
    }

    public void AlterarTotal(int totalvendas)
    {
        if(totalvendas < 0)
            throw new ArgumentException("O total não pode ser menor que 0");

        TotalVendas = totalvendas;
    }

    public void AlterarPercentual(double percentual)
    {
        if(percentual < 0)
            throw new ArgumentException("O percentual não pode ser menor que 0");

        Percentual = percentual;
    }

    public void CalcularComissao()
    {
        Console.WriteLine($"Comissão: {TotalVendas * Percentual}");
    }

    public void ExibirDados()
    {
        Console.WriteLine($"Nome: {Nome} || Matricula: {Matricula} || Salario: {Salario} || Percentual: {Percentual} || Total de Vendas: {TotalVendas}");
    }

}
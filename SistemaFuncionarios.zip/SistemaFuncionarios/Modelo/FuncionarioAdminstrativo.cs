using Func;
namespace FuncionarioAdm;

public class FuncionarioAdministrativo : Funcionario
{
    public string Departamento{get; private set;}
    public string Cargo{get; private set;}

    public FuncionarioAdministrativo(string nome, int matricula, decimal salario, string departamento, string cargo ) : base(nome,matricula,salario)
    {
        AlterarDepartamento(departamento);
        AlterarCargo(cargo);
    }

    public void AlterarDepartamento(string departamento)
    {
        if(string.IsNullOrWhiteSpace(departamento))
        {
            throw new ArgumentException("O departamento cadastrado deve ter caracteres");
        }

        Departamento = departamento;
    }

    public void AlterarCargo(string cargo)
    {
        if(string.IsNullOrWhiteSpace(cargo))
        {
            throw new ArgumentException("O cargo cadastrado deve ter caracteres");
        }

        Cargo = cargo;
    }

    public void ExibirDados()
    {
        Console.WriteLine($"Nome: {Nome} || Matricula: {Matricula} || Salario: {Salario} || Departamento: {Departamento} || Cargo: {Cargo}");
    }

}
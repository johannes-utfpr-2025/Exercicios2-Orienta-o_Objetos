﻿using Func;
using FuncionarioAdm;
using FuncionarioVendedor;

Console.WriteLine("----------------------------------");
Console.WriteLine("CRIANDO FUNCIONARIO ADMINISTRATIVO");
Console.WriteLine("----------------------------------");

var Administrador = new FuncionarioAdministrativo("Helena", 100, 5000, "RH", "Contador" );

Administrador.ExibirDados();

Console.WriteLine("----------------------------------");
Console.WriteLine("   CRIANDO FUNCIONARIO VENDEDOR   ");
Console.WriteLine("----------------------------------");

var Vendedor = new Vendedor("Marcos", 101, 3000, 15.8, 200);

Vendedor.ExibirDados();

Vendedor.CalcularComissao();
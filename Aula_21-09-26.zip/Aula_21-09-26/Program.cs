﻿using Encapsulamento.Modelo;

var tecnico = new Tecnico("Joao", 123);
var tecnico2 = new Tecnico("Helena", 145);
var tecnico3 = new Tecnico("Sofia", 156);

var manutencao = new Manutencao("Conserto de carro", DateTime.Now, tecnico);
var manutencao2 = new Manutencao("Manutenção de elevador", DateTime.Now, tecnico2);
var manutencao3 = new Manutencao("Manutenção de carro", DateTime.Now, tecnico3);

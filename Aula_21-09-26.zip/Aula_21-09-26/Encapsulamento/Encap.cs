namespace Encapsulamento.Modelo;

public class Tecnico
{
    public string Nome{get; private set;}
    public int RegistroProfissional {get; private set;}

    //Construtor
    public Tecnico(string nome, int registro )
    {
        AlterarNome(nome);
        AlterarRegistro(registro);
    }

    public void AlterarNome(string nome)
    {
        if(IsNullOrWhiteSpace(Nome))
            throw new ArgumentException("O nome precisa possuir caracteres");

        Nome = nome;
    }

    public void AlterarRegistro(int registro)
    {
        if(registro < 0)
            throw new ArgumentException("O registro precisa ser válido");

        RegistroProfissional = registro;
    }

}

public class Manutencao
{
    public string Descricao{get; private set;}
    public DateTime DataManutencao{get; private set;}
    public Tecnico tecnico_responsavel {get; private set;}

    //Construtor
    public Manutencao(string descricao, DateTime data, Tecnico tecnico)
    {
        AlterarDescricao(descricao);
        AlterarData(data);
        AlterarTecnico(tecnico);
    }

    public void AlterarDescricao(string descricao)
    {
        if(IsNullOrWhiteSpace(descricao))
            throw new ArgumentException("A descrição precisa possuir caracteres");

        Descricao = descricao;
    }

    public void AlterarData(DateTime data)
    {
        if(!DateTime.TryParse(data))
            throw new ArgumentException("A data não está valida");
        
        DataManutencao = data;
    }

    public Tecnico AlterarTecnico(Tecnico tecnico)
    {   
        Tecnico = tecnico;
    }
}
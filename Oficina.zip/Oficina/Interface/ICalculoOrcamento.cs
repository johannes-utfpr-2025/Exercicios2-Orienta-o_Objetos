using OrcamentoOficina;
namespace Interface
{

    public interface ICalculoOrcamento
    {
        decimal Calcular(decimal ValorPeca, int Horas);
    }

    public class CalculoPadrao : ICalculoOrcamento
    {
        public decimal Calcular(decimal ValorPeca, int Horas)
        {
            return ValorPeca + (Horas * 80);
        }
    }

    public class CalculoPrioritario : ICalculoOrcamento
    {
        public decimal Calcular(decimal ValorPeca, int Horas)
        {
            return ValorPeca + (Horas * 120) + 50;
        }
    }
}


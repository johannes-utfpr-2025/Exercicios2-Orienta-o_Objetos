using Interface;
namespace OrcamentoOficina
{
    public class Orcamento
    {
        public string Descricao{get; private set;}
        public decimal ValorPeca{get; private set;}
        public int Horas{get; private set;}

        public Orcamento(string descricao, decimal valor, int horas)
        {
            AlterarDescricao(descricao);
            AlterarValor(valor);
            AlterarHoras(horas);
        }

        public void AlterarDescricao(string descricao)
        {
            if(string.IsNullOrWhiteSpace(descricao))
                throw new ArgumentException("A descricao não pode ser nula");
            
            Descricao = descricao;
        }

        public void AlterarValor(decimal valor)
        {
            if(valor < 0)
                throw new ArgumentException("O valor não pode ser negativo");
            
            ValorPeca = valor;
        }

        public void AlterarHoras(int horas)
        {
            if(horas < 0)
                throw new ArgumentException("As horas não podem ser negativas");
            
            Horas = horas;
        }

        public void MostrarOrcamento(ICalculoOrcamento orcamento)
        {
            decimal Calculo = orcamento.Calcular(ValorPeca, Horas);
            Console.WriteLine($"Peça: {Descricao} || Valor Total: {Calculo}");
        }
    }
}
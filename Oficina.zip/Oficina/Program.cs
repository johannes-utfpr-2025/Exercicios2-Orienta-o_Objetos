﻿using System;
using Interface;
using OrcamentoOficina;

class Program
{
    static void Main(string[] args)
    {
        
        if (args.Length < 3)
        {
            Console.WriteLine("Informe 3 argumentos: [Tipo] [ValorPeca] [Horas]");
            return;
        }

        string tipo = args[0];
        string descricao = args[1];

        if (!decimal.TryParse(args[2], out decimal valor))
        {
            Console.WriteLine("O valor decimal deve ser valido.");
            return;
        }

        if (!int.TryParse(args[3], out int horas))
        {
            Console.WriteLine("O valor de horas deve ser um número válido.");
            return;
        }


        try 
        {
            var leitura = new Orcamento(descricao, valor, horas);

            ICalculoOrcamento iOrcamento;

            if (tipo.Equals("Padrao", StringComparison.OrdinalIgnoreCase))
            {
                iOrcamento = new CalculoPadrao();
            }
            else
            {
                iOrcamento = new CalculoPrioritario();
            }

            leitura.MostrarOrcamento(iOrcamento);
        }
        catch(ArgumentException ex)
        {
            Console.WriteLine($"Erro: {ex}");
        }
    }
}
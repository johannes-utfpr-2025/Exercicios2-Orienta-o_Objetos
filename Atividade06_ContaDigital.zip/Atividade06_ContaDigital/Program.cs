﻿using Encap.Modelo;

var conta1 = new Conta("João Silva", 1001);
var conta2 = new Conta("Maria Souza", 1002);

// Depósito inicial para saldo de teste
conta1.Depositar(1000.00m);

Console.WriteLine($"Saldo Inicial João (1001): R${conta1.Saldo}");
Console.WriteLine($"Saldo Inicial Maria (1002): R${conta2.Saldo}\n");

Console.WriteLine("1. Transferindo R$300,00 do João para a Maria...");
conta1.Transferir(300.00m, conta2);

Console.WriteLine($"[SUCESSO] Saldo João: R${conta1.Saldo}");
Console.WriteLine($"[SUCESSO] Saldo Maria: R${conta2.Saldo}\n");

//Invalido
//Console.WriteLine("2. Bloqueando conta da Maria e tentando transferir...");
//conta2.Bloquear();
//conta1.Transferir(100.00m, conta2); 

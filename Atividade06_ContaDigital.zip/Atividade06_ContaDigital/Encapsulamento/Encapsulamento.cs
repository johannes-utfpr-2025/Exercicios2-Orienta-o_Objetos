namespace Encap.Modelo;

public class Conta
{
    public string Nome {get; private set;}
    public decimal Saldo{get; private set;}
    public int Numero{get; private set;}
    public string Estado{get; private set;}

    //Construtor
    public Conta(string nome, decimal valor, int numero)
    {
        AlterarNome(nome);
        Saldo = 0;
        AlterarNumero(numero);
        Estado = "Desbloqueada";
    }

    public void AlterarNome(string ? novonome)
    {
        if(string.IsNullOrWhiteSpace(novonome))
            throw new ArgumentException("Nome não pode ser vazio!!!");

        Nome = novonome;
    }

    public void Depositar(decimal? novovalor)
    {
        if( Estado == "Bloqueada"  )
            throw new ArgumentException("Alguma conta esta bloqueada.");
        
        if( novovalor <= 0)
            throw new ArgumentException("O valor de depósito não pode ser menor que 0.");

        Saldo += (decimal)novovalor;
    }

    public void Sacar(decimal? novovalor)
    {
        if( Estado == "Bloqueada" )
            throw new ArgumentException("Alguma conta esta bloqueada.");
        
        if( novovalor <= 0)
            throw new ArgumentException("O valor de depósito não pode ser menor que 0.");
        
        if(novovalor <= Saldo)
            throw new ArgumentException("A conta não possui saldo suficiente.");

        Saldo -= (decimal)novovalor;
    }

    public void Transferir(decimal? valor, Conta? contaDestino)
    {
        ValidarContaAtiva();

        if (contaDestino == null)
            throw new ArgumentNullException(nameof(contaDestino), "A conta de destino não é válida.");

        if (contaDestino.Estado == "Bloqueado")
            throw new InvalidOperationException("A conta de destino está bloqueada.");

        if (Numero == contaDestino.Numero)
            throw new ArgumentException("A conta de origem e destino precisam ser diferentes.");

        // Realiza o saque na conta atual e o depósito na conta de destino
        Sacar(valor);
        contaDestino.Depositar(valor);
    }

    public void AlterarNumero(int? novonum)
    {
        if(novonum <= 0)
            throw new ArgumentException("O novo limite não pode ser igual ou menor que 0!!!");
        Numero = (int)novonum;
    }

    public void Bloquear()
    {
        if(Estado = "Bloqueado")
            Console.WriteLine("A conta já esta bloqueada");
        else
        {
            Estado = "Bloqueado";
        }

    }

    public void Desbloquear()
    {
        if(Estado = "Desbloqueado")
            Console.WriteLine("A conta já esta desbloqueada");
        else
        {
            Estado = "Desbloqueado";
        }
    }
}
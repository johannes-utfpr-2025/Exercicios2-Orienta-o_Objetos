namespace Encap.Modelo;

public class Encapsula
{
    public string Nome {get; private set;}
    public decimal Valor{get; private set;}
    public int Limite_usuarios{get; private set;}

    //Construtor
    public Encapsular(string nome, decimal valor, int limiteUsuarios)
    {
        AlterarNome(nome);
        AlterarValor(valor);
        AlterarLimite(limiteUsuarios);
    }

    public void AlterarNome(string ? novonome)
    {
        if(string.IsNullOrWhiteSpace(novonome))
            throw new ArgumentException("Nome não pode ser vazio!!!");

        Nome = novonome;
    }

    public void AlterarValor(decimal? novovalor)
    {
        if(novovalor <= 0)
            throw new ArgumentException("O valor não pode ser igual ou menor que 0!!!");
        Valor = (decimal)novovalor;
    }

    public void AlterarLimite(int? novolimite)
    {
        if(novolimite <= 0)
            throw new ArgumentException("O novo limite não pode ser igual ou menor que 0!!!");
        Limite_usuarios = (int)novolimite;
    }
}
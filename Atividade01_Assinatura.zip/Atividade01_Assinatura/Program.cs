﻿using Encap.Modelo;

//Tentativa valida
var objetoValido = new Encapsular("Plano Premium", 99.90m, 10);
Console.WriteLine($"[SUCESSO] Criado: {objetoValido.Nome} | Valor: R${objetoValido.Valor} | Limite: {objetoValido.Limite_usuarios}\n");

Console.WriteLine("2. Alterando o nome para um valor válido...");
var objeto = new Encapsular("Plano Básico", 29.90m, 2);
objeto.AlterarNome("Plano Empresarial");
Console.WriteLine($"[SUCESSO] Novo nome: {objeto.Nome}\n");

//Tentativa invalida
//Console.WriteLine("3. Tentando definir um nome vazio...");
//var objeto = new Encapsular("Plano Normal", 50.00m, 5);
//objeto.AlterarNome("   "); // Deve disparar exceção

//Console.WriteLine("4. Tentando definir valor menor ou igual a zero...");
//var objeto = new Encapsular("Plano Normal", 50.00m, 5);
//objeto.AlterarValor(-10.00m); // Deve disparar exceção

//Console.WriteLine("5. Tentando definir limite de usuários como zero...");
//var objeto = new Encapsular("Plano Normal", 50.00m, 5);
//objeto.AlterarLimite(0); // Deve disparar exceção
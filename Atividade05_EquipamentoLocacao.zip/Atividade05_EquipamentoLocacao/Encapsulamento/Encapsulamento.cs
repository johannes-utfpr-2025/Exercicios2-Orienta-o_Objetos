namespace Encap.Modelo;

public class Locacao
{
    public string Nome {get; private set;}
    public decimal Valor{get; private set;}
    public string Disponibilidade{get; private set;}

    //Construtor
    public Locacao(string nome, decimal valor)
    {
        AlterarNome(nome);
        AlterarValor(valor);
        Disponibilidade = "Disponivel";
    }

    public void AlterarNome(string ? novonome)
    {
        if(string.IsNullOrWhiteSpace(novonome))
            throw new ArgumentException("Nome não pode ser vazio!!!");

        Nome = novonome;
    }

    public void AlterarValor(decimal? novovalor)
    {
        if(novovalor <= 0)
            throw new ArgumentException("O valor não pode ser igual ou menor que 0!!!");
        Valor = (decimal)novovalor;
    }

    public void Reservar()
    {
        if(Disponibilidade == "Disponivel")
            Disponibilidade = "Reservado";
        else
        {
            throw new ArgumentException("O equipamento já está reservado ou não está disponível!!!");
        }
    }

    public void Retirar()
    {
        if(Disponibilidade == "Reservado")
            Disponibilidade = "Retirado";
        else
        {
            throw new ArgumentException("O equipamento não está reservado ou não está disponível!!!");
        }
    }

    public void Devolver()
    {
        if(Disponibilidade == "Retirado")
            Disponibilidade = "Disponivel";
        else
        {
            throw new ArgumentException("O equipamento já está reservado ou não está disponível!!!");
        }
    }
}
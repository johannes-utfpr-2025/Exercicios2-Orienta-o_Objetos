﻿using Encap.Modelo;
var item = new Locacao("Projetor HD", 120.00m);
Console.WriteLine($"[CRIADO] Item: {item.Nome} | Estado: {item.Disponibilidade}");

item.Reservar();
Console.WriteLine($"[RESERVADO] Estado atual: {item.Disponibilidade}");

item.Retirar();
Console.WriteLine($"[RETIRADO] Estado atual: {item.Disponibilidade}");

item.Devolver();
Console.WriteLine($"[DEVOLVIDO] Estado atual: {item.Disponibilidade}\n");

//Invalido
//Console.WriteLine("Tentando retirar diretamente sem reservar...");
//var item2 = new Locacao("Caixa de Som", 80.00m);
//item2.Retirar(); // Deve disparar exceção

//Console.WriteLine("Tentando devolver um item que está apenas reservado...");
//var item3 = new Locacao("Notebook", 200.00m);
//item3.Reservar();
//item3.Devolver();
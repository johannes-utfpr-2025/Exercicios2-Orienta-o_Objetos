﻿using Encap.Modelo;
//Teste válido
Console.WriteLine("[Teste 1] Criando conta ativa para a placa ABC-1234...");
Encapsula veiculo1 = new Encapsula("ABC-1234", 100.00m, "nao");
Console.WriteLine($"Sucesso! Placa: {veiculo1.Placa} | Saldo: {veiculo1.Saldo:C} | Bloqueado: {veiculo1.Bloqueio}");
//Alteração válida
Console.WriteLine("\nTentando adicionar +R$ 50,00 de saldo...");
veiculo1.AlterarValor(50.00m);
Console.WriteLine($"Sucesso! Novo Saldo: {veiculo1.Saldo:C}");

//Invalido
//Console.WriteLine("[Teste 3] Tentando criar conta com placa em branco...");
//Encapsula veiculo3 = new Encapsula("", 50.00m, false);

//Console.WriteLine("[Teste 4] Criando conta ativa e alterando bloqueio via texto...");
//Encapsula veiculo4 = new Encapsula("KGB-0007", 10.00m, false);
//Console.WriteLine($"Status inicial - Bloqueado: {veiculo4.Bloqueio}");

//Console.WriteLine("Bloqueando enviando o texto 'sim'...");
//veiculo4.AlterarBloqueio("sim");
//Console.WriteLine($"Novo Status - Bloqueado: {veiculo4.Bloqueio}");

//Console.WriteLine("Desbloqueando enviando o texto 'não'...");
//veiculo4.AlterarBloqueio("não");
//Console.WriteLine($"Novo Status - Bloqueado: {veiculo4.Bloqueio}");
            
//Console.WriteLine("Tentando passar um texto inválido ('talvez')...");
//veiculo4.AlterarBloqueio("talvez");
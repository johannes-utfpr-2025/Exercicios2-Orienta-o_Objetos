namespace Encap.Modelo;

public class Encapsula
{
    public string Placa {get; private set;}
    public decimal Saldo{get; private set;}
    public bool Bloqueio{get; private set;}

    //Construtor
    public Encapsula(string placa, decimal valor, string bloqueio)
    {
        AlterarPlaca(placa);
        AlterarValor(valor);
        AlterarBloqueio(bloqueio);
    }

    public void AlterarPlaca(string ? novaplaca)
    {
        if(string.IsNullOrWhiteSpace(novaplaca))
            throw new ArgumentException("A placa é obrigatória");

        Placa = novaplaca;
    }

    public void AlterarValor(decimal? novovalor)
    {
        if(novovalor < 0 || Bloqueio == true)
            throw new ArgumentException("O valor não pode ser menor que 0 ou o cartão está bloqueado.");

        Saldo += novovalor ?? 0;
    }

    public void AlterarBloqueio(string? texto)
    {
        if (texto == "s" || texto == "sim")
        {
            Bloqueio = true;
        }
        else if (texto == "n" || texto == "nao" || texto == "não")
        {
            Bloqueio = false;
        }
        else
        {
            throw new ArgumentException("Responda com sim ou nao !!!");
        }
    }
}
﻿using System;
using Encapsulamento.Modelo;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("==================================================");
        Console.WriteLine("          EXECUTANDO TESTES DE UNIDADE            ");
        Console.WriteLine("==================================================\n");

        ExecutarTestesServico();
        ExecutarTestesItemManutencao();
        ExecutarTestesOrdemServico();

        Console.WriteLine("\n==================================================");
        Console.WriteLine("             TESTES FINALIZADOS                   ");
        Console.WriteLine("==================================================");
    }

    static void ExecutarTestesServico()
    {
        Console.WriteLine("--- [ Testes: Servico ] ---");

        // Cenário 1: Sucesso ao criar Serviço
        TestarSucesso("Criar Serviço válido", () =>
        {
            var s = new Servico(1, "Troca de Óleo", 150.00m);
            if (s.Codigo != 1 || s.Descricao != "Troca de Óleo" || s.ValorBase != 150.00m)
                throw new Exception("Valores dos atributos incorretos.");
        });

        // Cenário 2: Erro - Código inválido
        TestarExcecao("Erro ao informar Código <= 0", () =>
        {
            new Servico(0, "Troca de Óleo", 150.00m);
        });

        // Cenário 3: Erro - Descrição vazia
        TestarExcecao("Erro ao informar Descrição vazia/espaço", () =>
        {
            new Servico(1, "   ", 150.00m);
        });

        // Cenário 4: Erro - Valor inválido
        TestarExcecao("Erro ao informar Valor <= 0", () =>
        {
            new Servico(1, "Troca de Óleo", 0m);
        });
    }

    static void ExecutarTestesItemManutencao()
    {
        Console.WriteLine("\n--- [ Testes: ItemManutencao ] ---");

        var servico1 = new Servico(1, "Troca de Óleo", 150.00m);
        var servico2 = new Servico(2, "Alinhamento", 80.00m);

        // Cenário 1: Sucesso ao criar ItemManutencao com serviço único
        TestarSucesso("Criar ItemManutencao com serviço único", () =>
        {
            var item = new ItemManutencao(servico1, 2, "Óleo sintético 5w30");
            if (item.Quantidade != 2 || item.Manutencao.Length != 1 || item.Observacao != "Óleo sintético 5w30")
                throw new Exception("Valores dos atributos incorretos.");
        });

        // Cenário 2: Observação vazia assume padrão "Sem observação"
        TestarSucesso("Observação vazia assume 'Sem observação'", () =>
        {
            var item = new ItemManutencao(servico1, 1, "   ");
            if (item.Observacao != "Sem observação")
                throw new Exception($"Esperado 'Sem observação', obtido '{item.Observacao}'");
        });

        // Cenário 3: Erro - Quantidade inválida
        TestarExcecao("Erro ao informar Quantidade <= 0", () =>
        {
            new ItemManutencao(servico1, -1, "Teste");
        });

        // Cenário 4: Erro - Serviços duplicados na mesma manutenção
        TestarExcecao("Erro ao inserir Serviço em duplicidade no mesmo ItemManutencao", () =>
        {
            new ItemManutencao(new[] { servico1, servico1 }, 1, "Duplicado");
        });
    }

    static void ExecutarTestesOrdemServico()
    {
        Console.WriteLine("\n--- [ Testes: OrdemServico ] ---");

        var servico = new Servico(1, "Troca de Óleo", 150.00m);
        var item1 = new ItemManutencao(servico, 1, "Item 1");
        var item2 = new ItemManutencao(servico, 2, "Item 2");

        // Cenário 1: Sucesso ao criar Ordem de Serviço
        TestarSucesso("Criar OrdemServico válida com itens", () =>
        {
            var os = new OrdemServico(1001, new[] { item1, item2 });
            if (os.Numero != 1001 || os.Itens.Length != 2)
                throw new Exception("Atributos da OrdemServico incorretos.");
        });

        // Cenário 2: Erro - Número de OS inválido
        TestarExcecao("Erro ao criar OS com Número <= 0", () =>
        {
            new OrdemServico(0);
        });

        // Cenário 3: Erro - Atribuir array de itens vazio ou nulo
        TestarExcecao("Erro ao atribuir lista de itens vazia", () =>
        {
            var os = new OrdemServico(1002);
            os.AtribuirItens(Array.Empty<ItemManutencao>());
        });

        // Cenário 4: Erro - Itens de manutenção duplicados
        TestarExcecao("Erro ao atribuir itens duplicados", () =>
        {
            var os = new OrdemServico(1003);
            os.AtribuirItens(new[] { item1, item1 });
        });
    }

    // Auxiliar para validar testes que DEVEM EXECUTAR COM SUCESSO
    static void TestarSucesso(string nomeTeste, Action acao)
    {
        try
        {
            acao();
            Console.WriteLine($"  [OK] {nomeTeste}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"  [FALHA] {nomeTeste} - Erro inesperado: {ex.Message}");
        }
    }

    // Auxiliar para validar testes que DEVEM LANÇAR ArgumentException
    static void TestarExcecao(string nomeTeste, Action acao)
    {
        try
        {
            acao();
            Console.WriteLine($"  [FALHA] {nomeTeste} - Deveria ter lançado exceção, mas passou.");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"  [OK] {nomeTeste} -> Exceção capturada: \"{ex.Message}\"");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"  [FALHA] {nomeTeste} - Lançou exceção de tipo inesperado ({ex.GetType().Name}): {ex.Message}");
        }
    }
}
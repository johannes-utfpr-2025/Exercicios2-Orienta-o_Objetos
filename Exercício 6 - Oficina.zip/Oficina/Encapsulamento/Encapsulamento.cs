using System;
using System.Linq;

namespace Encapsulamento.Modelo
{
    public class Servico
    {
        public int Codigo { get; private set; }
        public string Descricao { get; private set; }
        public decimal ValorBase { get; private set; }

        public Servico(int codigo, string descricao, decimal valor)
        {
            AlterarCodigo(codigo);
            AlterarDescricao(descricao);
            AlterarValor(valor);
        }

        public void AlterarDescricao(string descricao)
        {
            if (string.IsNullOrWhiteSpace(descricao))
                throw new ArgumentException("A descrição não pode ser vazia!!!");

            Descricao = descricao;
        }

        public void AlterarValor(decimal novovalor)
        {
            if (novovalor <= 0)
                throw new ArgumentException("O valor não pode ser igual ou menor que 0!!!");

            ValorBase = novovalor;
        }

        public void AlterarCodigo(int codigo)
        {
            if (codigo <= 0)
                throw new ArgumentException("O novo código não pode ser igual ou menor que 0!!!");

            Codigo = codigo;
        }
    }

    public class ItemManutencao
    {
        public Servico[] Manutencao { get; private set; }
        public int Quantidade { get; private set; }
        public string Observacao { get; private set; }

        // Construtor aceitando um único serviço
        public ItemManutencao(Servico manutencao, int quantidade, string observacao)
            : this(manutencao != null ? new[] { manutencao } : null, quantidade, observacao)
        {
        }

        // Construtor aceitando array de serviços
        public ItemManutencao(Servico[] servicos, int quantidade, string observacao)
        {
            AlterarServico(servicos);
            AlterarQuantidade(quantidade);
            AlterarObservacao(observacao);
        }

        public void AlterarQuantidade(int quantidade)
        {
            if (quantidade <= 0)
                throw new ArgumentException("A quantidade precisa ser maior que 0");

            Quantidade = quantidade;
        }

        public void AlterarObservacao(string observacao)
        {
            if (string.IsNullOrWhiteSpace(observacao))
            {
                Observacao = "Sem observação";
                return;
            }

            Observacao = observacao;
        }

        public void AlterarServico(Servico[] servicos)
        {
            if (servicos == null || servicos.Length == 0)
            {
                Manutencao = Array.Empty<Servico>();
                return;
            }

            if (servicos.Length != servicos.Distinct().Count())
            {
                throw new ArgumentException("Serviço inserido em duplicidade");
            }

            Manutencao = (Servico[])servicos.Clone();
        }
    }

    public class OrdemServico
    {
        public int Numero { get; private set; }
        public ItemManutencao[] Itens { get; private set; }

        public OrdemServico(int numero)
        {
            AlterarNumero(numero);
            Itens = Array.Empty<ItemManutencao>();
        }

        public OrdemServico(int numero, ItemManutencao[] itens) : this(numero)
        {
            AtribuirItens(itens);
        }

        public void AlterarNumero(int numero)
        {
            if (numero <= 0)
                throw new ArgumentException("O número da ordem de serviço precisa ser maior que 0");

            Numero = numero;
        }

        public void AtribuirItens(ItemManutencao[] itens)
        {
            if (itens == null || itens.Length == 0)
            {
                throw new ArgumentException("A quantidade de itens na ordem de serviço deve ser maior que 0.");
            }

            if (itens.Length != itens.Distinct().Count())
            {
                throw new ArgumentException("Item de manutenção inserido em duplicidade");
            }

            Itens = (ItemManutencao[])itens.Clone();
        }
    }
}
using System;
using System.Linq;

namespace Encapsulamento.Modelo
{
    public class Assento
    {
        public int Codigo { get; private set; }
        public int Coluna { get; private set; }
        public int Fileira { get; private set; }

        public Assento(int codigo, int fileira, int coluna)
        {
            AlterarAssento(codigo, fileira, coluna);
        }

        public void AlterarAssento(int codigo, int fileira, int coluna)
        {
            if (coluna < 0 || fileira < 0 || codigo < 0)
                throw new ArgumentException("O assento, o código ou a fileira não podem possuir números negativos.");

            Codigo = codigo;
            Fileira = fileira;
            Coluna = coluna;
        }

        
        public override bool Equals(object? obj)
        {
            if (obj is Assento outro)
            {
                return Codigo == outro.Codigo || (Fileira == outro.Fileira && Coluna == outro.Coluna);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Codigo, Fileira, Coluna);
        }
    }

    public class Sessao
    {
        public string Filme { get; private set; } = string.Empty;
        public DateTime Horario { get; private set; }
        public int CapacidadeMax { get; private set; }
        public Assento[] Reservados { get; private set; } = Array.Empty<Assento>();

        // Construtor
        public Sessao(string filme, string horario, int capacidade, Assento[] reservados)
        {
            AlterarFilme(filme);
            AlterarCapacidade(capacidade);
            AlterarHorario(horario);
            ReservarAssento(reservados);
        }

        public void AlterarFilme(string filme)
        {
            if (string.IsNullOrWhiteSpace(filme))
                throw new ArgumentException("O nome do filme não pode ser vazio!!!");

            Filme = filme;
        }

        public void AlterarCapacidade(int capacidade)
        {
            if (capacidade <= 0)
                throw new ArgumentException("A nova capacidade não pode ser igual ou menor que 0!!!");

            if (Reservados != null && Reservados.Length > capacidade)
                throw new ArgumentException("A nova capacidade não pode ser menor que a quantidade de assentos já reservados.");

            CapacidadeMax = capacidade;
        }

        public void ReservarAssento(Assento[] reservados)
        {
            if (reservados == null || reservados.Length == 0)
            {
                Reservados = Array.Empty<Assento>();
                return;
            }

            if (reservados.Length > CapacidadeMax)
                throw new ArgumentException("O número de assentos reservados excedeu a capacidade máxima.");

            if (reservados.Length != reservados.Distinct().Count())
            {
                throw new ArgumentException("Assento inserido em duplicidade.");
            }

            Reservados = (Assento[])reservados.Clone();
        }

        public void AlterarHorario(string horario)
        {
            if (!DateTime.TryParse(horario, out DateTime horarioParsed))
                throw new ArgumentException("O horário foi inserido de forma incorreta.");

            Horario = horarioParsed;
        }
    }
}
﻿using System;
using Encapsulamento.Modelo;

namespace Encapsulamento
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==================================================");
            Console.WriteLine("          INICIANDO BATERIA DE TESTES             ");
            Console.WriteLine("==================================================\n");

            // ----------------------------------------------------
            // TESTES DA CLASSE ASSENTO
            // ----------------------------------------------------
            Console.WriteLine("--- [TESTES: Assento] ---");

            // Teste 1: Criação Válida de Assento
            ExecutarTeste("Criar Assento Válido", () =>
            {
                var assento = new Assento(1, 10, 5);
                Assert(assento.Codigo == 1, "Código incorreto");
                Assert(assento.Fileira == 10, "Fileira incorreta");
                Assert(assento.Coluna == 5, "Coluna incorreta");
            });

            // Teste 2: Exceção para parâmetros negativos
            ExecutarTesteExcecao<ArgumentException>("Assento com número negativo (deve falhar)", () =>
            {
                new Assento(-1, 10, 5);
            });

            // ----------------------------------------------------
            // TESTES DA CLASSE SESSAO (FLUXO VÁLIDO)
            // ----------------------------------------------------
            Console.WriteLine("\n--- [TESTES: Sessão - Casos de Sucesso] ---");

            ExecutarTeste("Criar Sessão Válida e Validar Atribuição de Horário", () =>
            {
                var a1 = new Assento(1, 1, 1);
                var a2 = new Assento(2, 1, 2);
                
                var sessao = new Sessao("Inception", "2026-10-15 19:30", 50, new[] { a1, a2 });

                Assert(sessao.Filme == "Inception", "Nome do filme incorreto");
                Assert(sessao.CapacidadeMax == 50, "Capacidade incorreta");
                Assert(sessao.Reservados.Length == 2, "Quantidade de assentos reservados incorreta");
                Assert(sessao.Horario.Year == 2026 && sessao.Horario.Hour == 19, "Horario DateTime não foi preenchido corretamente");
            });

            ExecutarTeste("Criar Sessão sem Reservas Iniciais", () =>
            {
                var sessao = new Sessao("Matrix", "2026-10-15 21:00", 30, null!);
                Assert(sessao.Reservados.Length == 0, "Deveria ter zero assentos reservados");
            });

            // ----------------------------------------------------
            // TESTES DA CLASSE SESSAO (REGRAS DE NEGÓCIO E EXCEÇÕES)
            // ----------------------------------------------------
            Console.WriteLine("\n--- [TESTES: Sessão - Validação de Exceções] ---");

            // Teste: Nome do filme vazio
            ExecutarTesteExcecao<ArgumentException>("Filme Vazio/Espaço em Branco", () =>
            {
                new Sessao("   ", "2026-10-15 19:30", 50, Array.Empty<Assento>());
            });

            // Teste: Horário inválido
            ExecutarTesteExcecao<ArgumentException>("Formato de Horário Inválido", () =>
            {
                new Sessao("Batman", "horario_invalido", 50, Array.Empty<Assento>());
            });

            // Teste: Capacidade <= 0
            ExecutarTesteExcecao<ArgumentException>("Capacidade Maxima Igual a Zero", () =>
            {
                new Sessao("Batman", "2026-10-15 19:30", 0, Array.Empty<Assento>());
            });

            // Teste: Reservas acima da capacidade
            ExecutarTesteExcecao<ArgumentException>("Reservas Excedendo Capacidade Máxima", () =>
            {
                var a1 = new Assento(1, 1, 1);
                var a2 = new Assento(2, 1, 2);
                // Capacidade 1, mas passando 2 assentos
                new Sessao("Avatar", "2026-10-15 19:30", 1, new[] { a1, a2 });
            });

            // Teste: Assentos duplicados na lista
            ExecutarTesteExcecao<ArgumentException>("Assento Inserido em Duplicidade", () =>
            {
                var a1 = new Assento(1, 1, 1);
                var a1Duplicado = new Assento(1, 1, 1); // Mesmo código/posição

                new Sessao("Interstellar", "2026-10-15 19:30", 10, new[] { a1, a1Duplicado });
            });

            Console.WriteLine("\n==================================================");
            Console.WriteLine("          TODOS OS TESTES CONCLUÍDOS!             ");
            Console.WriteLine("==================================================");
        }

        #region Helpers de Teste
        static void ExecutarTeste(string nomeTeste, Action acao)
        {
            try
            {
                acao();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"[PASSOU] - {nomeTeste}");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[FALHOU] - {nomeTeste}: {ex.Message}");
            }
            finally
            {
                Console.ResetColor();
            }
        }

        static void ExecutarTesteExcecao<TExcecao>(string nomeTeste, Action acao) where TExcecao : Exception
        {
            try
            {
                acao();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[FALHOU] - {nomeTeste}: Nenhuma exceção foi lançada (esperava {typeof(TExcecao).Name}).");
            }
            catch (TExcecao)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"[PASSOU] - {nomeTeste} (Exceção capturada com sucesso)");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[FALHOU] - {nomeTeste}: Lançou {ex.GetType().Name} em vez de {typeof(TExcecao).Name}. Mensagem: {ex.Message}");
            }
            finally
            {
                Console.ResetColor();
            }
        }

        static void Assert(bool condicao, string mensagemErro)
        {
            if (!condicao)
                throw new Exception(mensagemErro);
        }
        #endregion
    }
}